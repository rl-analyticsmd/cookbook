
template "/etc/init.d/nomad-client" do 
	source "nomad_client.erb"
	owner 'root'
	group 'root'
	mode "0755"
end


service 'nomad-client' do
  action :start
end
