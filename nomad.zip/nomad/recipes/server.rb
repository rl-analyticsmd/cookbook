
template "/etc/init.d/nomad-server" do 
	source "nomad_server.erb"
	owner 'root'
	group 'root'
	mode "0755"
end

service 'nomad-server' do
  action :start
end
