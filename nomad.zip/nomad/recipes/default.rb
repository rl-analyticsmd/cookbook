#
# Cookbook Name:: nomad
# Recipe:: default
#
# Copyright 2016, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#

#require "pry"
directory node[:nomad][:home_dir] 



# execute 'create dir' do
# command "mkdir nomad_test"
# end

remote_file "#{node[:nomad][:home_dir]}/nomad_0.3.2_linux_amd64.zip" do
	source "https://releases.hashicorp.com/nomad/0.3.2/nomad_0.3.2_linux_amd64.zip"
end

# execute 'Download nomad file' do
	# command "wget https://releases.hashicorp.com/nomad/0.3.2/nomad_0.3.2_linux_amd64.zip"
# end

package 'unzip'

#binding.pry
execute 'To unzip the nomad folder' do
	cwd node[:nomad][:home_dir]
	command "unzip nomad_0.3.2_linux_amd64.zip"
	only_if "!(File.exist?("#{node[:nomad][:home_dir]}/nomad"))"
end



link "#{node[:nomad][:home_dir]}/nomad" do 
	to "/usr/bin/nomad"
	link_type :symbolic
end

directory "/etc/nomad.d" do 
	mode "0755"
	action :create
end


# execute 'change mode' do
# command "sudo chmod +x nomad; sudo mv nomad /usr/bin/nomad;sudo mkdir -p /etc/nomad.d;sudo chmod a+w /etc/nomad.d"
# end

#execute 'export' do
#command "export NOMAD_ADDR=http://192.168.152.99:4646"
#end
ruby_block "env Nomad Address" do 
	block do
		ENV["NOMAD_ADDR"]= "#{node[:nomad][:node_ip]}:#{node[:nomad][:port]}"
		#ENV["NOMAD_ADDR"]= "http://192.168.152.101:4646"
	end
end

template "#{node[:nomad][:home_dir]}/server.hcl" do
	source "server.hcl.erb"
end


template "#{node[:nomad][:home_dir]}/client.hcl" do
	source "client.hcl.erb"
end
