default[:nomad][:home_dir]="/opt/nomad_test"
default[:nomad][:node_ip]="http://192.168.152.101"
default[:nomad][:port]="4646"
