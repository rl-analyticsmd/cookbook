name             'zabbix_agent'
maintainer       'Relevance Lab Pvt LTD, Inc.'
maintainer_email 'ashish.raj@relevancelab.com'
license          'All rights reserved'
description      'Installs/Configures zabbix-agent'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.0'
