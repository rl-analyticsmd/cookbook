name             'AMDapplication'
maintainer       'Relevance Lab Pvt LTD, Inc.'
maintainer_email 'ashish.raj@relevancelab.com'
license          'All rights reserved'
description      'Installs/Configures AMDapplication'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.0'
