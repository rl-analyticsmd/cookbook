default['docker']['skipinter'] = "sudo DEBIAN_FRONTEND=noninteractive apt-get -y"
default['docker']['apt'] = "apt-get update"
default['docker']['yum'] = "yum -y update"



